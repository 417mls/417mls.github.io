---
title: 如是我闻
# 隐藏的模块
hide:
  - footer
  #  - navigation # 隐藏左边导航
  #  - toc #隐藏右边导航
  #  - footer #隐藏翻页
  #  - feedback  #隐藏反馈
comments: false  #评论，默认不开启
---

<!-- # 要么旅行，要么读书，身体和灵魂必须有一个在路上 -->



<div class="grid cards" markdown>

-   :material-clock-fast:{ .lg .middle } __要么旅行，要么读书，身体和灵魂必须有一个在路上__

    ---

    当你去到过很多地方  
    见过很多美景  
    经历过很多人和事  
    你就会逐渐明白  
    很多东西  
    虽然美  
    虽然你喜欢  
    却是你带不走的  
    是不属于你的  
    想通了这一点  
    你也就变得淡然和豁达了    
    我想  
    这就是旅行的意义吧

</div>