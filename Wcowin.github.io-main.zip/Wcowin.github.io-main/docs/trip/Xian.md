---
tags: [旅行]
comments: false  #评论，默认不开启
---

## 照片  


![IMG_1430.jpeg](https://s2.loli.net/2024/02/02/HXg92U5GamkPEIy.jpg)
![IMG_1458.jpeg](https://s2.loli.net/2024/02/02/XO7vRtPzbhHy3Jj.jpg)

<figure markdown>
  ![IMG_1936.jpeg](https://s2.loli.net/2024/02/02/yjk2KaGD3BfxiHP.jpg)
  <figcaption>李嘉仪童鞋</figcaption>
</figure>
![IMG_1546.jpeg](https://s2.loli.net/2024/02/02/4iMlwJpH8dcPfIO.jpg)
![IMG_4504.jpeg](https://s2.loli.net/2024/02/02/zdKxHn6EVswoIfF.jpg)

 
<figure markdown>
  ![IMG_1553_l2.jpeg](https://s2.loli.net/2024/02/02/rblH2jWC3kMgh7G.jpg)
  <figcaption>本人在左二 (｡ì _ í｡)</figcaption>
</figure>




## 路线
**西安**

D1：西安城墙（可骑单车）——兵马俑（预约）一华清池（预约）——钟楼/回民街（干饭）

D2： 陕历博（预约）一大雁塔/大慈恩寺——大唐不夜城/(大唐芙蓉园)

D3: 找同学耍

D4: 返程

## 美食  

腊汁肉夹馍、凉皮、羊肉泡馍、臊子面  
***
羊肉泡馍
![IMG_1956.jpeg](https://s2.loli.net/2024/02/02/PRGTuEAhBHC1cny.jpg)
biangbiang面
![IMG_1671.jpeg](https://s2.loli.net/2024/02/02/ciM53ybvoHzrCwm.jpg)  
汇通十字面
![IMG_4555.jpeg](https://s2.loli.net/2024/02/02/gCdDbWr94zF8Rj2.jpg)
霸王茶姬
![IMG_1506.jpeg](https://s2.loli.net/2024/02/02/zwSAuC8ODphf3K9.jpg)