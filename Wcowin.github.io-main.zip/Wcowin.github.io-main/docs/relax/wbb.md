---
title:  王冰冰
# 隐藏的模块
hide:
  #  - navigation # 隐藏左边导航
  #  - toc #隐藏右边导航
  #  - footer #隐藏翻页
  #  - feedback  #隐藏反馈
tags:
    - My Love
comments: false  #评论，默认不开启
---

<!-- <iframe src="//player.bilibili.com/player.html?aid=347852412&bvid=BV1rR4y1f7mA&cid=896199338&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" style="width: 640px; height: 430px; max-width: 100%"> </iframe> -->
![](http://user-assets.sxlcdn.com/images/805944/FsdVhyfxszA5LgymzUs4n-Cdqj7s.jpeg?imageMogr2/strip/auto-orient/thumbnail/1920x9000%3E/quality/90!/interlace/1/format/jpeg)

## 履历
<font color=#F09898 size=7>王冰冰</font>  

<font color=#4B91F1>  

中国内地记者、媒体人。  
 
王冰冰，出生于吉林省长春市，中国内地女记者、主持人 ，毕业于吉林大学播音专业。  
 
别称：**查干湖恶霸**、胖头鱼公主等。  
 
2012年，进入吉林日报社《城市晚报》实习  

2016年，进入中央广播电视总台工作  

2019年，担任“2019年中央广播电视总台春节联欢晚会”吉林分会场采访记者。  

2020年11月2日，主持的“青年大学习”网上主题团课上线；  

11月18日，参加央视新闻和BOSS直聘联合推出的《“职”为你来》秋招公益直播   

2021年2月28日，获得“2020微博之夜年度热点人物榜”21名 ；  

6月2日起，为央视网出品军旅纪录片《新兵请入列》担任配音。  

8月5日，参加央视网出品的新青年生活分享类综艺节目《你好生活第三季》播出 ；  

8月13日，参加由央视频推出的主播新媒体才艺秀《央young之夏》播出 ；  

9月10日，参加央视新闻推出的《CBD汽车直播夜》直播；  

9月中下旬，参加中华人民共和国第十四届运动会的多项赛事的报道；  

10月起，在央视新闻《全国红色故事讲解大赛》中作为主持人：  

10月16日，参加上海举行的“中国时装盛典”并参与“五美”展示；  

10月中旬，参与CGTN“海上看中国”系列报道；  

11月5日-10日，对第四届上海进博会进行全方面的报道；  

12月12日，参与共青团主办的《青春出发2021》第一季第一集，去往吉林省延边朝鲜族自治州;  

12月，参加由央视频推出的节目《冬日暖央young》，以推动冬奥宣传；  

第五届“中国青年好网民”优秀故事评选中当选；  

2022年，1月1日，参加总台首档青年新年分享类节目《@青春，2022！》  

1月，为迎接北京冬奥会，《冰冰带你上冰雪》《中国冰雪盛典》等衍生节目推出，来通过王冰冰亲身体验冰雪运动来普及冬奥和冰雪知识；  

小年夜参加2022年中央电视台《网络春晚》；  

哔哩哔哩2021年最佳新人奖获得者； 

2021中国品牌人物500强;  

1月，在央视频和哔哩哔哩上线了自己的运动员零距离式采访节目《闪闪发光的少年》；  

1月31日（除夕），对2022中央广播电视总台春节联欢晚会进行探班，并在CCTV13除夕特别节目《龙腾虎跃中国年》中开始专题“冰冰带你探春晚”；  

2月7日，“央young”系列《开工喜央young》播出；

7月13日，总台农业农村中心和成都电视台制作并推广的慢综艺《冰冰带你来种田》正式启动，总台记者王冰冰将与嘉宾们一起享受农耕慢生活；  

11月21日，央视频3周年和世界杯开幕式央视频预热节目《央视频之夜》直播，王冰冰担任主持人之一；  

11月22日，参与文化知识节目《国之大雅》播出。 

11月下旬至12月中旬，央视频推出《欧雷欧雷陪看团》和《球迷梦之夜》两档卡塔尔世界杯相关直播节目，王冰冰担任嘉宾和主持人；  

12月16日，《闪闪发光的少年》第二季正式在央视频和哔哩哔哩上线！

2023年  
1月11日至20日，由王冰冰配音的纪录片《奇妙中国》将在CCTV9、央视频等平台播出；  

1月14日小年夜，参加中央广播电视总台2023年《网络春晚》；  

1月15日，央视新闻联合科技部人才与科学普及司、中国科协科普部和总台北京总站举办的《酷啊未来 中国科技创新之夜》，王冰冰参与；  

1月19日，王冰冰作为中央广播电视总台2023央视频重点节目片单发布会主持人，同时发布众多央视频节目；  

癸卯新年前夕，王冰冰参与了中央广播电视总台春节联欢晚会的新媒体衍生节目《春晚进行时》和《young在春晚》；  

春节期间，王冰冰将参与CCTV3《吉聚欢喜》，用七部生活轻喜剧，串联出万千家庭蓬勃锐气的年味故事，烘托出当代中国醇厚馨香的欢乐节庆；  

第二届中国春兰节将于2月16日至2月19日举行，中央民族乐团团长赵聪,知名作家麦家 与总台记者王冰冰化身“春兰使者”，与你相约绍兴柯桥，共赴一场兰花之约；  

3月1日，总台青春分享类节目《青春@2023》在央视新闻、央视网播出，总台记者化身“青春电台”主播。

3月21日，在泉州参加"好物泉都来"专场带货；  

4月初，水气清，菜花黄，又见一年柳如烟。王冰冰向你发出“春日之约”，在这个清明节，共赴2023中国（开封）清明文化节，共同感受景清气明，万物生长；  

4月2日，王冰冰邀你体验今年踏青新玩法~央视新闻发起青年创作者闪耀计划；  

4月13日，央视频特别节目《乘着大巴看中国》来到成都。总台主持人孟湛东、总台记者王冰冰与你相约蓉城，打卡全国糖酒会，一起诗酒趁年华；  

4月18日，王冰冰向你发出邀请！一起走进全球首个超时空参与式博物馆；  

4月23日，央视新闻《健康公开课》节目。北京协和医院专家陈伟与总台记者王冰冰畅聊减肥方法；  

4月27日，蒙牛携手中国航天20周年之际，央视新闻带来独家直播。总台记者王冰冰担任节目主持人，邀您与中国航天一起共同点亮未来；  

5月2日，《吉聚欢喜》 以喜剧底色演绎温馨、有趣的假期故事，呈现一份欢乐治愈的假日生活图鉴；  

5月19日中国旅游日，2023杭州 •临安吴越文化节开幕晚会播出，围绕“天目叠翠，吴越千年”的主题，多个原创编排内容将亮相开幕晚会，结合沉浸式舞台表演、嘉宾创意推介、创意短片等多种形式，在主持人尼格买提、王冰冰的串联下，呈现千年吴越的文化积淀与文明传承，多维度展现临安之韵、临安之美；  

资深媒体人、制片人王雪纯将在抖音迎来个人IP系列直播《纯游记》的收官场次。  

5月21日 （小满）  
下午16:30-18:30，雪纯邀请王冰冰担任直播嘉宾，走进中国传媒大学，进行一场主题为“跨越时空共赴青春”的直播。在直播间，两代媒体人跨越时空后现场同框，分享属于自己的校园故事。
6月3日，你好生活第四季正式开始录制，王冰冰参与录制；  

6月10日是文化和自然遗产日，王冰冰来到佛山，探索这座岭南古城的非遗魅力。狮头扎作、铜凿剪纸…记录数不清的非遗文化；

6月14日，中国影视之夜举办暨CMG融媒影城启幕，王冰冰饰演薛宝钗。 

6月16日，央视新闻联合拼多多带来的百亿补贴带货直播，任鲁豫王冰冰为你推荐四川特色；  

6月22日~24日，每天20:15，关注CCTV-17《生活有点田》，阳光很好，一起开工！

7月14日，《中国短视频大会》开播，王冰冰和尼格买提主持；  

7月中旬，《追时间的厨房》正式开播，王冰冰作为嘉宾；  

7月22日，王冰冰作为嘉宾参与《你好生活》第四季。

8月13日、14日，央视新闻系列节目《走！一起探秘国家公园》。总台记者王冰冰和嘉宾王昱珩走进三江源国家公园，一起护送“高原精灵”大迁徙；
“尼好，戏剧！青年导演创作扶持计划第二季·走进济宁”开幕式于8月13日在山东济宁曲阜尼山圣境盛大启幕。罗一舟、王冰冰携手主持，国话群星集体亮相，国学气韵的主题演出，一场儒学与戏剧的双向奔赴！  

2023烟台国际葡萄酒节启动仪式暨“微醺烟台”系列活动发布会于8月18日下午举行。总台主持人任鲁豫、记者王冰冰担任本场主持人，共同发布“微醺烟台”系列活动；  

8月22日17:00，飞鹤携手央视新闻带你沉浸式寻源首个中国婴幼儿黄金奶源地，一起解锁尼格买提和王冰冰的新身份；  

8月24日起，《一馔千年》团建篇高能来袭，馔家族全员集结，王冰冰作为嘉宾；  

8月25日，唐代诗人贺知章重回故乡萧山，与总台记者王冰冰在萧山机场共同唱响杭州亚运主题歌曲《同爱同在》；  

8月30日，以钢铁意志摘贫油之帽，以冲天干劲解少油之难。"铁人精神"赓续不止！面对"贫油国"的帽子王进喜义愤填膺，如何才能摘帽子？"有条件要上，没有条件创造条件也要上""宁可少活二十年，拼命也要拿下大油田"一代代像王进喜一样的石油人秉持着"铁人精神"积极进取，为祖国分忧，为民族争气，换来了如今的生活。王进喜诞辰100周年之际，让我们向王进喜同志致敬！（王冰冰解说）；  

9月13日，李白先生"穿越"回故里绵阳？总台记者王冰冰带"李白"细品当代小吃？在中国唯一科技城绵阳探索科技含量，细数上天入海的"绵阳造"，聆听两弹元勋们的感人故事。关注央视新闻《"青"爱的城》，随王冰冰一起"蜀来蜀去数绵阳"；  

9月15日，激扬赛场 轮动四方 王冰冰作为嘉宾；  

9月22日，总台记者王冰冰@吃花椒的喵酱 和吕小品化身“大侦探”，破解头等沙发的秘密；  

9月30日，音乐快递｜“冰皮月饼”邀你过双节；  

10月12日，总台主持人高博，总台记者王冰冰推介总台2024品牌强国工程发布活动；  

跟随王冰冰[@吃花椒的喵酱](https://space.bilibili.com/2026561407/dynamic) ，强子，符龙飞，蒋诗萌，隋卞和深圳博物馆讲解员袁旭一起感受深圳速度，品味深圳美食~10月14日，来央视频看《“小美好”中国行》，一起向生活小美好出发。
 
</font>  

**（以上内容由[冰学网](https://mywbb.mysxl.cn/){target=“_blank”}综合各类信息编辑）插一嘴：这站长老哥是真喜欢冰冰[@吃花椒的喵酱](https://space.bilibili.com/2026561407/dynamic)**
***
## **美图奉上😘**

![](http://user-assets.sxlcdn.com/images/805944/FuPmbkF-MeeIgcF7YQJLay7fhp5r.jpeg?imageMogr2/strip/auto-orient/thumbnail/1920x9000%3E/quality/90!/interlace/1/format/jpeg)
![](http://user-assets.sxlcdn.com/images/805944/Fm0oCwyRA2JHaw-Gu8VmwWjTJ56Q.png?imageMogr2/strip/auto-orient/thumbnail/1920x9000%3E/quality/90!/format/png)
<!-- ![](http://user-assets.sxlcdn.com/images/805944/Fsg-4QEtJ-OvpdsH9BAqi1InddMg.png?imageMogr2/strip/auto-orient/thumbnail/1920x9000%3E/quality/90!/format/png) -->
![](http://user-assets.sxlcdn.com/images/805944/FiH-mvvoM8HvG7eaf7MmFS_um_NJ.jpeg?imageMogr2/strip/auto-orient/thumbnail/1920x9000%3E/quality/90!/interlace/1/format/jpeg)
![](http://user-assets.sxlcdn.com/images/805944/FgnNZ5bcMgm4WGqFIJhCZg4H_0Vy.jpeg?imageMogr2/strip/auto-orient/thumbnail/1920x9000%3E/quality/90!/interlace/1/format/jpeg)
![](http://user-assets.sxlcdn.com/images/805944/FjE5gIwWJknieTfYvPMWSRs6y84m.jpeg?imageMogr2/strip/auto-orient/thumbnail/!300x300r/gravity/Center/crop/300x300/quality/90!/interlace/1/format/jpeg)
![](http://user-assets.sxlcdn.com/images/805944/Fl2oW3qEPRL9bZPY1Z64JF__q8jE.png?imageMogr2/strip/auto-orient/thumbnail/!300x300r/gravity/Center/crop/300x300/quality/90!/format/png)
![](http://user-assets.sxlcdn.com/images/805944/FvQxnEkIj3NIlZ83YfDAV93rLxsh.jpeg?imageMogr2/strip/auto-orient/thumbnail/!300x300r/gravity/Center/crop/300x300/quality/90!/interlace/1/format/jpeg)
![](http://user-assets.sxlcdn.com/images/805944/FvNV5aPOLrFH1aEAoCN7cy-jvmme.jpeg?imageMogr2/strip/auto-orient/thumbnail/!200x200r/gravity/Center/crop/200x200/quality/90!/interlace/1/format/jpeg)

![](http://user-assets.sxlcdn.com/images/805944/FojYbVWHLoJNWAkrX23A45C9D2E6.jpeg?imageMogr2/strip/auto-orient/thumbnail/!300x300r/gravity/Center/crop/300x300/quality/90!/interlace/1/format/jpeg)
![](http://user-assets.sxlcdn.com/images/805944/FhNP2Flp78YRjFO1bMq0nwAem5px.jpeg?imageMogr2/strip/auto-orient/thumbnail/!300x300r/gravity/Center/crop/300x300/quality/90!/interlace/1/format/jpeg)

![](http://user-assets.sxlcdn.com/images/805944/FuA2YhHBIyRkCguA3hjDmq_AiHMj.jpeg?imageMogr2/strip/auto-orient/thumbnail/!200x200r/gravity/Center/crop/200x200/quality/90!/interlace/1/format/jpeg)
![](http://user-assets.sxlcdn.com/images/805944/Fr0b-lZkzH_QiqdQXqjcWH4qufmH.png?imageMogr2/strip/auto-orient/thumbnail/!200x200r/gravity/Center/crop/200x200/quality/90!/format/png)
![](http://user-assets.sxlcdn.com/images/805944/FtIBw15hQZOF3Xwh8s4XlXY5Npvi.jpeg?imageMogr2/strip/auto-orient/thumbnail/!200x200r/gravity/Center/crop/200x200/interlace/1/format/jpeg)
![](http://user-assets.sxlcdn.com/images/805944/FsdVhyfxszA5LgymzUs4n-Cdqj7s.jpeg?imageMogr2/strip/auto-orient/thumbnail/1920x9000%3E/quality/90!/interlace/1/format/jpeg)  
![](http://user-assets.sxlcdn.com/images/805944/FrqBmLVChZp-Ttjh99l1Z7rkTyIi.jpeg?imageMogr2/strip/auto-orient/thumbnail/1920x9000%3E/quality/90!/interlace/1/format/jpeg)
![Alt text](https://user-assets.sxlcdn.com/images/805944/FvKN_N6KJ68H25NIy92Hh09fk9QL.jpeg?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1200x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FoHMK09eBbwW-lNQsLonpNUmtOLJ.jpeg?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1920x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/Fr-1dCF-kODT5FdzFFshJXk57PpI.png?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1920x9000%3E%2Fquality%2F90%21%2Fformat%2Fpng)
![](https://user-assets.sxlcdn.com/images/805944/FmPtQboeRUUUKB0w4V5i181pXyqc.jpeg?imageMogr2/strip/auto-orient/thumbnail/720x1440%3E/quality/90!/interlace/1/format/jpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FoT9bdBjAhu1GTOqoFK2U4Qa58iO.jpeg?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1920x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpeg)
![](http://user-assets.sxlcdn.com/images/805944/FrqBmLVChZp-Ttjh99l1Z7rkTyIi.jpeg?imageMogr2/strip/auto-orient/thumbnail/1920x9000%3E/quality/90!/interlace/1/format/jpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FoyL1kxHduJI4WsVPLT6Q9xis4T3.jpeg?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1920x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpeg)
![Alt text](https://user-assets.sxlcdn.com/images/805944/FqUrymeeZPGMBBIRmjp9kzkvKEDQ.jpg?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1200x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FiqIxdBMh5wTtKD5XMdx0JC26_s5.JPG?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1920x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FvO2ma_nxKzOPpO4f8mGbalKhD1r.JPG?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1920x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FhOsqt74gNzc6eLgECqwt28jUFml.JPG?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1920x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FtAhD9mbv2dNmTL3Qj9ZM8-bTd5l.JPG?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1920x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/Fq1zSM_yKHGZm-IxG5B1wb1PS5Sc.jpg?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1920x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/Fo5buNDo3ScHKbH333qKF_AqtRiX.jpg?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1920x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/Foaajf74g57myq9XgaCWkGub3Hb5.jpg?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1920x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FqTqNdc88iK7tflHNFWy2DOdFDfJ.jpg?imageMogr2%2Fstrip%2Fauto-orient%2Fthumbnail%2F1920x9000%3E%2Fquality%2F90%21%2Finterlace%2F1%2Fformat%2Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/Fh4UIml9LRcXvbWxFabWzm-Qrmmn.JPG?imageMogr2%252Fstrip%252Fauto-orient%252Fthumbnail%252F1920x9000%253E%252Fquality%252F90%2521%252Finterlace%252F1%252Fformat%252Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FpirI4h0XJlLeKIFAVxzeDv2o2PM.JPG?imageMogr2%252Fstrip%252Fauto-orient%252Fthumbnail%252F1920x9000%253E%252Fquality%252F90%2521%252Finterlace%252F1%252Fformat%252Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/Fng7qhVcQlEGQ-BXm8rdkls9Rvmy.JPG?imageMogr2%252Fstrip%252Fauto-orient%252Fthumbnail%252F1920x9000%253E%252Fquality%252F90%2521%252Finterlace%252F1%252Fformat%252Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/Fs1nf_zPnIAf5T7E-rAQboKrv31C.JPG?imageMogr2%252Fstrip%252Fauto-orient%252Fthumbnail%252F1920x9000%253E%252Fquality%252F90%2521%252Finterlace%252F1%252Fformat%252Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FjwRANM-BPp2cuyAxY0glPPAQhCt.JPG?imageMogr2%252Fstrip%252Fauto-orient%252Fthumbnail%252F1920x9000%253E%252Fquality%252F90%2521%252Finterlace%252F1%252Fformat%252Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FqvoaTxeZ0xo6BTCA13THTMmvOmb.JPG?imageMogr2%252Fstrip%252Fauto-orient%252Fthumbnail%252F1920x9000%253E%252Fquality%252F90%2521%252Finterlace%252F1%252Fformat%252Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FuCfDui64dLhZD3_2XnETzzOwuNE.jpg?imageMogr2%252Fstrip%252Fauto-orient%252Fthumbnail%252F1920x9000%253E%252Fquality%252F90%2521%252Finterlace%252F1%252Fformat%252Fjpeg)![Alt text](http://user-assets.sxlcdn.com/images/805944/FgrA_oyC1lKcyFWQSbo6UlWw2SjO.jpg?imageMogr2%252Fstrip%252Fauto-orient%252Fthumbnail%252F1920x9000%253E%252Fquality%252F90%2521%252Finterlace%252F1%252Fformat%252Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FquKQBluji4tWcAcfYN_I3b1CA4l.jpg?imageMogr2%252Fstrip%252Fauto-orient%252Fthumbnail%252F1920x9000%253E%252Fquality%252F90%2521%252Finterlace%252F1%252Fformat%252Fjpeg)
![Alt text](http://user-assets.sxlcdn.com/images/805944/FiwyetIQ0GmXtGwVqJ62PESFhVQB.jpg?imageMogr2%252Fstrip%252Fauto-orient%252Fthumbnail%252F1920x9000%253E%252Fquality%252F90%2521%252Finterlace%252F1%252Fformat%252Fjpeg)
![](http://user-assets.sxlcdn.com/images/805944/FsGMQC5y3tJRIl2dwHaJ0RQ9uYyt.jpeg?imageMogr2/strip/auto-orient/thumbnail/1920x9000%3E/quality/90!/interlace/1/format/jpeg)