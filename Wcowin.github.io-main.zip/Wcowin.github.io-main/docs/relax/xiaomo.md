
<font face="宋体" color=orange size=6><b>:simple-xiaomi:</font><font face="宋体" color=orange size=7>永远相信美好的事情即将发生</b> </font>

- <h2>小米的使命：始终坚持做“感动人心、价格厚道”的好产品，让全球每个人都能享受科技带来的美好生活</h2>

!!! info
    <font face="宋体" >小米公司正式成立于2010年4月，是一家以智能手机、智能硬件和 IoT 平台为核心的消费电子及智能制造公司。创业仅7年时间，小米的年收入就突破了千亿元人民币。截止2018年，小米的业务遍及全球80多个国家和地区。  

    小米的使命是，始终坚持做 **“感动人心、价格厚道”** 的好产品，让全球每个人都能享受科技带来的美好生活。</font>
![](https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/c6f46fb63c119d83d2b4b38505fffbcd.jpg?w=1226&h=450)
![](https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/8dda571ff4ae30170d4300e177f62af7.jpg?w=1226&h=768)
***
## 三条铁律
**技术为本  性价比为纲  做最酷的产品**
<b>
未来十年的三大策略：

重新创业  互联网+制造  行稳致远

下一个十年，

创新之火将会照亮每个疯狂的想法，小米将成为工程师向往的圣地。

下一个十年，

智能生活将彻底影响我们每个人，小米将成为未来生活方式的引领者。

下一个十年，

智能制造将进步助力中国品牌的崛起，小米将成为中国制造业不可忽视的新兴力量。

下一个十年，

小米将成为一条蜿蜒奔涌的长河，流过全球每个人的美好生活，奔向所有人向往的星辰大海。
</b>
**相信自己，一往无前！**

## 关于小米
<!-- [关于小米](https://cdn.cnbj1.fds.api.mi-img.com/staticsfile/pc/about/struggle.mp4) -->
<!-- ![xiaomi](https://user-assets.sxlcdn.com/images/951476/FhDY4DJUZ76Xz3CJ6sdjBLIZV-si.jpg?imageMogr2/strip/auto-orient/thumbnail/1920x9000%3E/quality/90!/interlace/1/format/jpeg) -->

<a href="https://cdn.cnbj1.fds.api.mi-img.com/staticsfile/pc/about/struggle.mp4">
    <img src="https://user-assets.sxlcdn.com/images/951476/FhDY4DJUZ76Xz3CJ6sdjBLIZV-si.jpg?imageMogr2/strip/auto-orient/thumbnail/1920x9000%3E/quality/90!/interlace/1/format/jpeg" >
  </a>

<!-- <iframe  src="https://cdn.cnbj1.fds.api.mi-img.com/staticsfile/pc/about/struggle.mp4" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" style="width: 720px; height: 400px; max-width: 100%"></iframe>   -->
小米创业8年内部影像资料，首次公开！

<!-- <iframe src="//player.bilibili.com/player.html?aid=27087520&bvid=BV1Ps411E7w6&cid=46647207&page=1" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true" style="width: 640px; height: 430px; max-width: 100%"> </iframe> -->

<iframe width="560" height="315" max-width: 100% src="//player.bilibili.com/player.html?aid=27087520&bvid=BV1Ps411E7w6&cid=46647207&page=1" title="YouTube video player" frameborder="0" allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<!-- <iframe frameborder=0 border="0" marginwidth="0" marginheight="0" scrolling="no" height=720 width=1280 src="https://cdn.cnbj1.fds.api.mi-img.com/staticsfile/pc/about/struggle.mp4"></iframe> -->

<iframe width="560" height="315" scrolling="no" max-width: 100% src="https://cdn.cnbj1.fds.api.mi-img.com/staticsfile/pc/about/struggle.mp4" title="YouTube video player" frameborder="0" allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<!-- <link type="text/css" rel="stylesheet" href="/ckplayer/css/ckplayer.css" />
<script type="text/javascript" src="/ckplayer/js/ckplayer.js" charset="UTF-8"></script>
<div class="video" style="width: 660px;height: 450px;">播放器容器</div>
<script type="text/javascript">
    //定义一个变量：videoObject，用来做为视频初始化配置
    var videoObject = {
        container: '.video', //“#”代表容器的ID，“.”或“”代表容器的class
        smallWindows:null,//是否启用小窗口模式
        poster: 'https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/c6f46fb63c119d83d2b4b38505fffbcd.jpg?w=1226&h=450',//封面图片地址
        webFull:true,//是否启用页面全屏按钮，默认不启用
        video: 'https://cdn.cnbj1.fds.api.mi-img.com/staticsfile/pc/about/struggle.mp4'//视频地址
    };
    var player = new ckplayer(videoObject);//初始化播放器
</script> -->

***

## 雷总专辑单曲

<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=31814005&auto=0&height=66"></iframe>

<!-- height=720 width=1280 -->