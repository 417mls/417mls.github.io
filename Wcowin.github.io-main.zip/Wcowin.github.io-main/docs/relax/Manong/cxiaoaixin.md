```c
#include<stdio.h>
int main()
{ 
for( ; ; )
   {printf("❤️\n");
   }
   return 0;
} 
```


<iframe style="width: 100%; background-color: #151617; border-radius: 8px; height: 680px;" src="https://1024code.com/embed-ide/@Wcowin/XHpDVaJ"></iframe>