---
title: 支持作者
---

# 支持作者

<div class="grid cards" markdown>

- :material-email-mark-as-unread: 给我发送[邮箱](mailto:wcowin@qq.com)

- :material-github: [点击此处](https://github.com/Wcowin/Wcowin.github.io){target="\_blank" rel="noopener"}访问Github仓库

</div>


可以的话 请我喝一杯咖啡吧☕️

**:simple-alipay:** **Alipay**

![](https://s2.loli.net/2024/02/01/ps8UM6xu2OL3Dyr.jpg){class="img1"}

**:simple-wechat:** **WeChat Pay**

![](https://s2.loli.net/2024/02/01/cxrEKTLp5CiQeBw.jpg){class="img1"}

***
**:simple-kofi:ko-fi**

[Touch me!](https://ko-fi.com/U6U5HAO6B){ .md-button target=_blank}


<div class="reward-container">
  <div></div>
  <button style="border-radius: 0.5rem;" onclick="var qr = document.getElementById('qr'); qr.style.display = (qr.style.display === 'none') ? 'block' : 'none';">
    请作者喝杯咖啡
  </button>
  <div id="qr" style="display: none;">
      <div style="display: inline-block;">
        <img src="https://s2.loli.net/2024/02/01/cxrEKTLp5CiQeBw.jpg" alt="Wcowin 微信支付">
        <p>微信支付</p>
      </div>
      <div style="display: inline-block;">
        <img src="https://s2.loli.net/2024/02/01/ps8UM6xu2OL3Dyr.jpg" alt="Wcowin 支付宝">
        <p>支付宝</p>
      </div>
  </div>
</div>



