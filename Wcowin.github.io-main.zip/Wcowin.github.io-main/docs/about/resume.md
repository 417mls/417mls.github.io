
<div class="grid cards" markdown>

-   :octicons-bookmark-16:{ .lg .middle } __个人简历__

    ---

    - [个人简历](https://lightpdf.cn/docs/1cpgobc){target=“_blank”}

</div>