---
title: 友链
comments: true
hide:
#   - navigation # 显示右
#   - toc #显示左
  - footer
  - feedback
---

<!-- <head>
<script>
function _howxm(){_howxmQueue.push(arguments)}
window._howxmQueue=window._howxmQueue||[];
_howxm('setAppID','14429fca-cac1-4551-a472-b046a96ebb75');
(function(){var scriptId='howxm_script';
if(!document.getElementById(scriptId)){
var e=document.createElement('script'),
t=document.getElementsByTagName('script')[0];
e.setAttribute('id',scriptId);
e.type='text/javascript';e.async=!0;
e.src='https://static.howxm.com/sdk.js';
t.parentNode.insertBefore(e,t)}})();
</script>
</head> -->

<!-- <div class="markdown-content">
    <h2>欢迎加入友链(不分先后)</h2>
</div> -->

# 欢迎加入友链(不分先后)
<div id="rcorners4" >

  <div class="links-content"> 
   <div class="link-navigation"> 
    <div class="card"> 
     <img class="ava" src="https://s2.loli.net/2024/02/01/gaE47y5fKM6kosV.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://wcowin.work/ " target="_blank">Wcowin's Web</a> 
      </div> 
      <div class="info">
       “循此苦旅，以达星辰”
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://s2.loli.net/2024/02/07/S8GYheTZmCU96HK.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://wcowin.work/WH-WKW/" target="_blank">小王和王老师的小站</a> 
      </div> 
      <div class="info">
        无一是你，无一不是你
      </div> 
     </div> 
    </div> 
    <div class="card"> 
     <img class="ava" src="https://xpmrobot.tech/images/portrait.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://xpmrobot.tech/" target="_blank">Xpm's Robot Lab</a> 
      </div> 
      <div class="info">
       星星之火可以燎原
      </div> 
     </div>
    </div>
   <div class="card"> 
     <img class="ava" src="https://www.crant.cn/upload/Avatar.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://www.crant.cn/" target="_blank">Crant</a> 
      </div> 
      <div class="info">
       用心记录，美好生活
      </div> 
     </div> 
    </div> 
    <div class="card"> 
     <img class="ava" src=" https://finisky.github.io/images/avatar.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://finisky.github.io/" target="_blank">Finisky Garden</a> 
      </div> 
      <div class="info">
       互联网技术那些事儿
      </div> 
     </div> 
    </div>
       <div class="card"> 
     <img class="ava" src="https://mungeryang.github.io/images/avatar.png?v=1696728951294" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://mungeryang.github.io/" target="_blank">Munger yang's Blog</a> 
      </div> 
      <div class="info">
       Mungeryang写字的地方
      </div> 
     </div>
    </div> 
       <div class="card"> 
     <img class="ava" src="https://img.ixintu.com/upload/jpg/20210524/3a8cbb0f2da716313a3b18984a9ffe73_78863_800_772.jpg!con" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://wcowin.work/myhexo/" target="_blank">Myhexo</a> 
      </div> 
      <div class="info">
       Wcowin的个人Hexo网站
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://gravatar.cdn.iszy.xyz/avatar/5012e410377c7a93d14f7bf31aeeb7fd?d=mm" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://www.iszy.cc/" target="_blank">随遇而安</a> 
      </div> 
      <div class="info">
       生活吐槽＆学习记录
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://s2.loli.net/2024/02/01/NcLn4XdMWQKV37f.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://qiuyuair.com" target="_blank">Qiuyuair的自留地</a> 
      </div> 
      <div class="info">
       Airyu’s Site
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://www.gkcoll.xyz/favicon.ico" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://www.gkcoll.xyz/" target="_blank">极客藏源</a> 
      </div> 
      <div class="info">
       探索互联网新大陆 in N ways.
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://s2.loli.net/2024/02/01/2Ju6y1fmpWDUBaz.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://www.cnblogs.com/miluluyo/" target="_blank">麋鹿鲁哟</a> 
      </div> 
      <div class="info">
       大道至简，知易行难
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://image.h4ck.org.cn/wp-content/uploads/2023/11/gh_84aaef91c283_430-1.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://h4ck.org.cn/" target="_blank">obaby@mars</a> 
      </div> 
      <div class="info">
       爱好广泛的火星小妖精
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://www.yaguwu.com/1.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://www.yaguwu.com/" target="_blank">雅故小筑</a> 
      </div> 
      <div class="info">
       寻一处小筑，不遇车马喧器
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://cdn.dusays.com/avatar.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://dusays.com" target="_blank">杜老师说</a> 
      </div> 
      <div class="info">
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://agentestudio.com/uploads/post/image/69/main_how_to_design_404_page.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://www.luckyzh.cn/" target="_blank">旧梦</a> 
      </div> 
      <div class="info">
       冰冻三尺非一日之寒
       滴水穿石非一日之功
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://qkongtao.cn/file/images/favicon.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://qkongtao.cn/" target="_blank">左眼会陪右眼哭の博客</a> 
      </div> 
      <div class="info">
       干嘛这么想不开，要在脸上贴个输字！
      </div> 
     </div> 
    </div>    
   <div class="card"> 
     <img class="ava" src="https://www.zair.top/img/logo.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://www.zair.top/" target="_blank">以太工坊</a> 
      </div> 
      <div class="info">
       分享我的学习笔记、经验与有趣的小玩意.
      </div> 
     </div> 
    </div>      
   <div class="card"> 
     <img class="ava" src="https://s2.loli.net/2024/06/25/59hnlap8m3oyBrk.webp" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://xiaofeishu-boke.netlify.app/" target="_blank">没用的小废鼠的Blog</a> 
      </div> 
      <div class="info">
       做学问可不是赶潮流、没有冷门热门之说。
      </div> 
     </div> 
    </div>  
   <div class="card"> 
     <img class="ava" src="https://ejsoon.win/wp-content/uploads/2022/08/alogobg.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://ejsoon.win" target="_blank">天蒼人頡</a> 
      </div> 
      <div class="info">
       發掘好玩事物
      </div> 
     </div> 
    </div>    
   <div class="card"> 
     <img class="ava" src="https://npm.onmicrosoft.cn/hrn-img@1.0.0/img/avatar.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.lvhrn.cn" target="_blank">JayHrn</a> 
      </div> 
      <div class="info">
       發掘好玩事物
      </div> 
     </div> 
    </div> 
   <div class="card"> 
     <img class="ava" src="https://www.langhai.net/assets/images/langhai-logo.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://www.langhai.net/" target="_blank">浪海导航</a> 
      </div> 
      <div class="info">
       浪海导航 ~ 收录各种类型的博客
      </div> 
     </div> 
    </div> 
   <div class="card"> 
     <img class="ava" src="https://blog.moraxyc.com/avatar.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://moraxyc.com" target="_blank">Moraxyc’s Rhapsody</a> 
      </div> 
      <div class="info">
       永远热爱！
      </div> 
     </div> 
    </div> 
   <div class="card"> 
     <img class="ava" src="https://pic.vimin.cc/logo.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://vimin.cc/" target="_blank">XIAOMING'S BLOG</a> 
      </div> 
      <div class="info">
  记录生活点滴，谱写精彩生活！
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://fastly.jsdelivr.net/gh/wkk-dev/cdn@master/png/kang-qq.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.wkk-dev.top" target="_blank">WKK & Blog</a> 
      </div> 
      <div class="info">
      天生我材必有用，千金散尽还复来。
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://bu.dusays.com/2022/12/28/63ac2812183aa.png
     " /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.zhheo.com/" target="_blank">张洪Heo</a> 
      </div> 
      <div class="info">
      分享设计与科技生活
      </div> 
     </div> 
    </div>    
   <div class="card"> 
     <img class="ava" src="https://blog.lichenghao.cn/avatar.svg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.lichenghao.cn" target="_blank">故事的程序猿</a> 
      </div> 
      <div class="info">
      好好学习，天天向上↑
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://blog.btwoa.com/btwoa.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.btwoa.com" target="_blank">btwoa</a> 
      </div> 
      <div class="info">
      世界为你简单
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://blog.linsnow.cn/img/avatar.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.linsnow.cn" target="_blank">L1nSn0w's Blog</a> 
      </div> 
      <div class="info">
      无限进步.🎈
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://note.isshikih.top/_assets/iro/IroPatch_Brown.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://note.isshikih.top/" target="_blank">IsshikiHugh's Notebook</a> 
      </div> 
      <div class="info">
      我们登上高塔，看到的却只有黑夜……
      </div> 
     </div> 
    </div>    
   <div class="card"> 
     <img class="ava" src="https://blog.whispery.cn/img/tou.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.whispery.cn/" target="_blank">Whisper</a> 
      </div> 
      <div class="info">
      我们的忧愁将会崩解灵魂将会穿梭如风
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://bu.dusays.com/2023/12/23/65867c3357bb6.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://kegongteng.cn/" target="_blank">Kegongteng</a> 
      </div> 
      <div class="info">
      Blogger / Technophile / Student
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://s2.loli.net/2024/03/31/Ht3QBqhgLYNAuwj.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://lennychen.top/" target="_blank">Lenny's Web</a> 
      </div> 
      <div class="info">
      天地不仁，以万物为刍狗
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://i.postimg.cc/MGCXBFxn/logo.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://tkqtang.github.io" target="_blank">tkqtang’s Web</a> 
      </div> 
      <div class="info">
      所谓自由，不是随心所欲，而是自我主宰
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://avatars.githubusercontent.com/u/111767754?v=4" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://arv-anshul.github.io/about/" target="_blank">Anshul Raj Verma</a> 
      </div> 
      <div class="info">
      Introduction: Let's learn together and Build together.
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://avatars.githubusercontent.com/u/81922999?v=4" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.meta-code.top/" target="_blank">百里飞洋の博客</a> 
      </div> 
      <div class="info">
      星河滚烫，无问西东
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://weizwz.com/img/avatar/head.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://weizwz.com" target="_blank">唯之为之</a> 
      </div> 
      <div class="info">
      时光笔墨
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://www.imerduo.com/wp-content/uploads/2023/12/0c55c83b6a18155f_01-150x150.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://www.imerduo.com" target="_blank">耳朵的主人</a> 
      </div> 
      <div class="info">
      耳朵电台，庆幸我们还有耳朵
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://blog.sunguoqi.com/avatar.webp" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.sunguoqi.com" target="_blank">小孙同学</a> 
      </div> 
      <div class="info">
      路虽远行则将至，事随难做则必成！
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://baiwumm.com/avatar.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://baiwumm.com/" target="_blank">白雾茫茫丶</a> 
      </div> 
      <div class="info">
      记录学习、生活和有趣的事
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://blog.w1ndys.top/img/about/avatar.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.w1ndys.top/" target="_blank">W1ndysの小屋</a> 
      </div> 
      <div class="info">
      欲戴皇冠，必承其重
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://cdn.zerolacqua.top/images/avatar.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.zerolacqua.top" target="_blank">丘卡饮品店</a> 
      </div> 
      <div class="info">
      要来点喝的吗？
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://yy.liveout.cn/photo/photo2.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://www.liveout.cn/" target="_blank">Echo 的小窝</a> 
      </div> 
      <div class="info">
      漂泊于互联网中的小窝
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://npm.elemecdn.com/anzhiyu-blog-static@1.0.4/img/avatar.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.anheyu.com/" target="_blank">安知鱼</a> 
      </div> 
      <div class="info">
      生活明朗，万物可爱
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://npm.elemecdn.com/nanshen/avatar.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.imzjw.cn" target="_blank">小嘉的部落格</a> 
      </div> 
      <div class="info">
      一个爱折腾的Java开发工程师
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://npm.elemecdn.com/webxc/logo/logo.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://webxc.eu.org" target="_blank">小城故事</a> 
      </div> 
      <div class="info">
      欢迎光临小城故事!
      </div> 
     </div> 
    </div>
   <div class="card"> 
     <img class="ava" src="https://www.styg.org.cn/zb_users/upload/2024/01/202401261706277157705448.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://www.styg.org.cn/" target="_blank">温岭慈善义工石塘服务队</a> 
      </div> 
      <div class="info">
       慈善义工在行动
      </div> 
     </div> 
    </div> 
   <div class="card"> 
     <img class="ava" src="https://www.notion.so/image/https%3A%2F%2Fprod-files-secure.s3.us-west-2.amazonaws.com%2F7880b046-93bb-4d63-a4e2-64814819b3e8%2Ffea4ed7b-d9d4-419a-b526-de9e020205d4%2Favatar.png?table=block&amp;id=d9b5a704-94ee-45aa-b6fe-f1572c4d9b26&amp;t=d9b5a704-94ee-45aa-b6fe-f1572c4d9b26&amp;width=800&amp;cache=v2" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://www.linyunlink.top/" target="_blank">凌云·LinYun</a> 
      </div> 
      <div class="info">
       “因为热爱而生”
      </div> 
     </div> 
    </div>  
    <div class="card"> 
     <img class="ava" src="http://www.ickg.net/vis/favicon.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="http://www.ickg.net" target="_blank">iCKG 渝见</a> 
      </div> 
      <div class="info">
       我和重庆有个约会
      </div> 
     </div> 
    </div>
    <div class="card"> 
     <img class="ava" src="https://blog.asyncx.top/favicon.svg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.asyncx.top/" target="_blank">AsyncX</a> 
      </div> 
      <div class="info">
       🌌 Per Aspera Ad Astra
      </div> 
     </div> 
    </div>
    <div class="card"> 
     <img class="ava" src="https://avatars.githubusercontent.com/u/11755104?v=4" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://meekdai.com" target="_blank"> Meekdai</a> 
      </div> 
      <div class="info">
       童话是一种生活态度，仅此而已。
      </div> 
     </div> 
    </div>
    <div class="card"> 
     <img class="ava" src="https://pic.imgdb.cn/item/65bc52b0871b83018a06699d.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.imsyy.top/" target="_blank">無名小栈</a> 
      </div> 
      <div class="info">
       分享技术与科技生活
      </div> 
     </div> 
    </div>
    <div class="card"> 
     <img class="ava" src="https://blog.pantheon.press/wp-content/uploads/v2-f73763905eed23308466e441430a43be_r-150x150.jpg" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://blog.pantheon.press" target="_blank">pantheon</a> 
      </div> 
      <div class="info">
      </div> 
     </div> 
    </div>
    <div class="card"> 
    <img class="ava" src="https://s2.loli.net/2024/07/02/uKs2Jqo9THROipr.jpg" /> 
    <div class="card-header"> 
      <div> 
      <a href="https://frankoxer.github.io" target="_blank">Frankoxer</a> 
      </div> 
      <div class="info">
      别急，过会儿就更新
      </div> 
    </div> 
    </div>
    <div class="card"> 
    <img class="ava" src="https://tendcode.com/static/blog/img/friend.png" /> 
    <div class="card-header"> 
      <div> 
      <a href="https://tendcode.com" target="_blank">TendCode</a> 
      </div> 
      <div class="info">
      Django自建博客，热爱Python
      </div> 
    </div> 
    </div>
    <div class="card"> 
    <img class="ava" src="https://www.chujiaweicode.top/static/favicons/icon32.png" /> 
    <div class="card-header"> 
      <div> 
      <a href="https://www.chujiaweicode.top/" target="_blank">Jiawei’s Blog</a> 
      </div> 
      <div class="info">
    和光同尘
      </div> 
    </div> 
    </div>


   </div> 
  </div>





<!-- <div class="markdown-content">
    <h2>失联人员</h2>
</div> -->

<HR style="FILTER: progid:DXImageTransform.Microsoft.Shadow(color:#608DBD,direction:145,strength:15)" width="100%" color=#608DBD SIZE=1>


</div>


<!-- <HR style="FILTER: progid:DXImageTransform.Microsoft.Shadow(color:#608DBD,direction:145,strength:15)" width="100%" color=#608DBD SIZE=1> -->

<br>

# 失联人员
<div id="rcorners4" >
  <div class="links-content"> 
   <div class="link-navigation"> 
   <div class="card"> 
     <img class="ava" src="https://agentestudio.com/uploads/post/image/69/main_how_to_design_404_page.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="http://liis.cc" target="_blank">郝宇博客</a> 
      </div> 
      <div class="info">
       记录我的成长和青春
      </div> 
     </div> 
    </div>
    <div class="card"> 
     <img class="ava" src="https://raw.githubusercontent.com/get1024/RyanJoy-s_Web/main/docs/public/avatar.png" /> 
     <div class="card-header"> 
      <div> 
       <a href="https://get1024.github.io/RyanJoy-s_Web/" target="_blank">RyanJoy's Web</a> 
      </div> 
      <div class="info">
       🌟且视他人之疑目如盏盏鬼火，大胆地去走自己的夜路吧
      </div> 
     </div> 
    </div>


   </div> 
  </div>
  <HR style="FILTER: progid:DXImageTransform.Microsoft.Shadow(color:#608DBD,direction:145,strength:15)" width="100%" color=#608DBD SIZE=1>
</div>





<div class="markdown-content">
    <h3>交换友链，请添加本站友链后下方留言申请，期望您的站点:</h3>
</div>


<!-- <div class="card">
   <img class="ava" src="{avatarurl}" />
   <div class="card-header">
      <div>
         <a href="{link}">{name}</a>
      </div>
      <div class="info">{description}</div>
   </div>
</div> -->   

* 独立博客(不要求独立域名)，https，访问流畅
* 原创内容为主，原创内容3篇以上
* 处于活跃状态，有一定的更新频率
* 建站一个月以上
* 未添加友链或申请未通过，评论留言会被隐藏。

本站已经加入[十年之约](https://www.foreverblog.cn/)：
<a href="https://www.foreverblog.cn/" target="_blank" > <img src="https://img.foreverblog.cn/logo_en_default.png" alt="" style="width:auto;height:16px;"> </a>请放心添加本站友链

***

**友链格式示例/本站信息:**

<!-- >名称: Wcowin's Web  
>链接: https://wcowin.work/  
>头像: https://s2.loli.net/2024/02/01/gaE47y5fKM6kosV.png  
>简介: 循此苦旅，以达星辰 -->

=== "Txt"

    >名称: Wcowin's Web  
    >链接: https://wcowin.work/  
    >头像: https://s2.loli.net/2024/02/01/gaE47y5fKM6kosV.png  
    >简介: 循此苦旅，以达星辰

=== "HTML(推荐)"

    推荐在评论区发送这种格式，*号的需要填写自己的信息

    ```html
    <div class="card"> 
     <img class="ava" src="*你的头像链接*" /> 
     <div class="card-header"> 
      <div> 
       <a href="*你的网站地址* " target="_blank">*你的站点名称*</a> 
      </div> 
      <div class="info">
       *你的站点描述*
      </div> 
     </div> 
    </div>
    ```
=== "Butterfly"

    ```yaml
    - name: Wcowin's Web
      link: https://wcowin.work/
      avatar: https://s2.loli.net/2024/02/01/gaE47y5fKM6kosV.png 
      descr: 循此苦旅，以达星辰
    ```
=== "通用"

    点击填写[**友链申请**问卷](https://wj.qq.com/s2/14878680/20ac/)  

    [![](https://s2.loli.net/2024/06/27/9gw37T4vPASxiD8.png){width=50%}](https://wj.qq.com/s2/14878680/20ac/)

    
***