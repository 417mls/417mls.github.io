---
title: 利用Lighthouse测试网站性能
tags:
  - 技术分享
---

![image.png](https://s2.loli.net/2024/02/04/yxwcmJLXADqMa8P.png)

打开谷歌或者Edge浏览器，按F12，在右侧点"➕"找到Lighthouse,点击分析页面载即可    
