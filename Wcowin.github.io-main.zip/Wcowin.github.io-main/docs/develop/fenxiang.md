---
tags:
  - 技术分享
---
貌似也没什么新闻☺︎  
科技寒冬.png

来聊聊那些大厂的良心到难以置信的软件叭  
—————————————————  
## 腾讯  :simple-tencentqq:

[QQ影音](https://player.qq.com/)（无广告全平台解码器）    
[Foxmail](https://www.foxmail.com/)（轻量化个人邮箱，无限空间，无广告客户端）  
[VooV](https://voovmeeting.com/)（视频会议平台)  
[腾讯柠檬清理](https://lemon.qq.com/)（Mac清理工具）  
[腾讯智影](https://zenvideo.qq.com/home)（一站式在线创作工具）  
[腾讯桌面整理](https://guanjia.qq.com/product/zmzl/)（文件分类、磁盘映射、精确搜索！记得选择独立版本下载，不如腾讯电脑管家+1)  

## 阿里 :simple-alibabadotcom: 
[阿里企业邮](https://exmail.aliyun.com/free)（永久免费自定义域名邮箱)  
[阿里矢量图标库](https://www.iconfont.cn/)（海量矢量图标免费下载)  
[夸克网盘](https://pan.quark.cn/?chkey=undefined)（网盘美观好用）

## 百度  :simple-baidu:
[飞桨 AI Studio](https://aistudio.baidu.com/aistudio/index)（免费AI、图形相关的GPU算力，量大管饱)  
[图说](https://tushuo.baidu.com/)（图表编辑器)

## 360   
[360 Zip](http://www.360totalsecurity.com/360zip/)（无广告、无捆绑压缩软件）  
[手心输入法](https://www.xinshuru.com/)（无广告，安卓剪贴板兼容性好)

## 华为  :simple-huawei:
[花瓣测速](https://consumer.huawei.com/cn/support/content/zh-cn15821163/)（无广告，轻量化，多用途的网络测试工具)  
[花瓣剪辑](https://consumer.huawei.com/cn/mobileservices/petalclip/)（AI剪辑！一键成片！人人都可以快速创作！)  
[手机克隆](https://consumer.huawei.com/cn/emui/clone/)（安卓/鸿蒙一键迁移，离线操作不留痕迹)

## 迅雷  
[光影魔术手](http://www.neoimaging.cn/)（一键P图换背景软件，开箱即用，不过2014后就没更新了

## 字节跳动  :material-ideogram-cjk:
[Icon Park](https://iconpark.oceanengine.com/home)（免费开源图标站)

## Google :material-google:
[Google Fonts](https://fonts.google.com/)（谷歌字体，千余种字体在线浏览，设计师狂喜)  
[Google Ngram Viewer](https://books.google.com/ngrams)（历史文献关键词分析工具，meme创造机)  
[Talk to Books](https://books.google.com/talktobooks/)（一个博览群书的AI，与书籍对话，与历史对话)

## Microsoft  :material-microsoft:
[Math](https://math.microsoft.com/)（逐步的数学解题工具，包含各种可视化工具)  
[Power BI](https://powerbi.microsoft.com/)（超棒的大数据可视化分析工具，绝对炫酷  
[Azure Free](https://azure.microsoft.com/zh-cn/free/)（永久免费的NoSQL服务、IoT Edge、每月全球100GB的免费出站流量等等  
[Github](https://github.com/)（全球最大同性交友平台🌚

## Cloudflare  :simple-cloudflare:
[1.1.1.1](https://1.1.1.1/)（全平台的网络加速软件，WARP+！)  
[Workers](https://www.cloudflare.com/zh-cn/products/workers/)（No Server的去中心化边缘计算节点，月50K限额)  
还有免费CDN、DDOS防御和零信任平台，良心～

## Amazon  :simple-amazon:
[Amazon SES/SNS](https://aws.amazon.com/cn/free/)（商用免费邮件传递服务，62K/月免费使用量

## IBM   :simple-ibm: 
[IBM Watson](https://www.ibm.com/cloud/free)®（强大的AI调用库，文字语音互转、文本翻译、语义分析、视觉识别、自然语言处理等应有尽有，每月限额 )   
[IBM® Db2® on Cloud](https://www.ibm.com/cloud/free)（200MB的IBM数据库，永久免费)

## Adobe  
[Adobe Photoshop Express](https://www.microsoft.com/store/productId/9WZDNCRFJ27N)（轻量版Photoshop，开箱即用易上手)  
[Adobe Fresco](https://apps.microsoft.com/store/detail/XP8C8R0ZKZR27V)（绘图&上色工具，为艺术家而生)  
[Adobe 调色盘](https://color.adobe.com/zh/create)（妈妈再也不用担心我找不到好看的配色啦！)