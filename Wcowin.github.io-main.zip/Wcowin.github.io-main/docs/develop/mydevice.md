---
tags:
  - 技术分享
---

# 我的设备  

## </p><h1 id="01" name="01"><strong>Macbook pro</strong></h1><p>
<figure markdown>
  ![image.png](https://s2.loli.net/2024/02/03/awndem3rYPyNGOj.png){ width="500" }
  <figcaption>Macbook pro 13-inch, M1, 2020</figcaption>
</figure>

## </p><h1 id="01" name="01"><strong>Mobile phone</strong></h1><p>

<figure markdown>
  ![image.png](https://s2.loli.net/2024/02/03/Seg6RfjOa1MU2Zo.png){ width="300" }
  <figcaption>iPhone 13</figcaption>
</figure>

## </p><h1 id="01" name="01"><strong>U盘</strong></h1><p>
Aigo 256G
## </p><h1 id="01" name="01"><strong>域名</strong></h1><p>
<font  color= #518FC1 size=6>[wcowin.work](https://wcowin.work)</font>

## <h1 id="01" name="01"><strong>开发工具</strong></h1>
* Vs code :material-microsoft-visual-studio-code:
* Xcode :simple-xcode:
* PyCharm :simple-pycharm:
* WebStorm :simple-webstorm:
***
* Git :simple-git:
* npm :fontawesome-brands-npm:
* Node.js :fontawesome-brands-node:
* vue :material-vuejs:
* [SwitchHost](https://switchhosts.vercel.app/zh)  :material-toggle-switch:
* Mkdocs/mkdocs-material :logo-monochrome:
***
* Arc/Chrome/Safari浏览器 :simple-safari:
* GitHub :material-github:
* CSDN :material-file-code:
***
* Apple music :simple-applemusic: