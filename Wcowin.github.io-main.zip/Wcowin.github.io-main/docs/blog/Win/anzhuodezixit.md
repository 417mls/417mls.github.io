---
title: 安卓的子系统
tags:
  - win
---

2023.3.21 挖个坑

适用于 Android™️ 的 Windows 子系统:<https://learn.microsoft.com/zh-cn/windows/android/wsa/>{target=“_blank”}