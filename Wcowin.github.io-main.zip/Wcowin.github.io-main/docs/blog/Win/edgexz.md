---
tags:
  - win
---
![](https://edgefrecdn.azureedge.net/shared/edgeweb/img/RE4U3ak.a902b21.jpg)  
第一步：管理员模式打开 powershell   

第二步：  
```
cd 'C:\Program Files (x86)\Microsoft\Edge\Application\*\Installer  
```
第三步：
```
./setup --uninstall --force-uninstall --system-level
```