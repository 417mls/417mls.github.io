---
title: 2022网站更新记录
authors: [Wcowin]
date: 2022-06-06
categories:
  - 网站更新记录
readtime: 2
---

## </p><h1 id="01" name="01"><strong>2022-10-20</strong></h1><p>
* 建立Github仓库，正式建站
* 取消cookie确认,简化网站打开流程
* 新增首页反馈收集 

## </p><h1 id="01" name="01"><strong>2022-10-06</strong></h1><p>

* 不靠父母，全款拿下 [wcowin.work](https://wcowin.work/){target="_blank"}域名
* 取消cookie确认，保障隐私

## <h1 id="01" name="01"><strong>2022-06-06</strong></h1>

* 研究如何建设网站，初步定框架为MKdocs
* 早期网址：<https://github.com/Wcowin/mymkdocs>