---
title: Ke Xue Shang Wang
tags:
  - 技术分享
---
!!! Note "流程"
    * 准备工作：科学上网客户端如Clsah，Quantumult X，小火箭(Shadowrocket)
    * 拥有一个订阅节点 
    * 将节点导入到科学上网客户端
    * 打开科学上网客户端开始网上冲浪～ 


**因为阿里域名警告，有关TG的文章，梯子的问题，暂时不更新**

## 客户端下载  
### ios  

需要使用**外区Apple ID**购买Shadowrocket或者Quantumult X  
<https://www.rocketgirls.space>{target=_blank} (推荐购买地址)
***
### Android

<https://github.com/Kr328/ClashForAndroid>{target=_blank}
***
### PC/Mac  

<https://github.com/Dreamacro/clash>{target=_blank}  
***
Shadowrocket/clash新手使用教程:<https://telegra.ph/departure-airport-05-29>{target=_blank}  
Mac第三方客户端Clash教程:<https://flm88.blog/p/docs/mac-clash>{target=_blank}  
Windows第三方客户端Clash教程:<https://flm88.blog/p/docs/windows-clash>{target=_blank}

最后可以打开[这个页面](https://www.google.com/?hl=zh-CN&sa=X&ved=0ahUKEwjTmpfQ-u31AhVaEXAKHUcyBmcQnZcCCAc){target=_blank}即为成功：[谷歌](https://www.google.com/?hl=zh-CN&sa=X&ved=0ahUKEwjTmpfQ-u31AhVaEXAKHUcyBmcQnZcCCAc){target=_blank} 

## 推荐机场:material-vpn:
  
- [一元机场](https://一元机场.com/#/dashboard){target=_blank}  
- [三分机场](https://三分机场.xyz/){target=_blank}  
- [魔戒](https://mojie.me/#/dashboard){target=_blank}
## 图文教程
[科学上网、工具、教程项目库](https://github.com/bannedbook/fanqiang){target=_blank}  
[一份不负责任的机场使用手册（转载）](https://www.duyaoss.com/archives/1086/){target=_blank}
## 须知
> 声明：科学上网是为了更好的学习，因为很多国外网站要科学上网，如[Github](https://github.com/)等，**切勿使用做违法的事情，切勿相信墙外任何不当言论，反对台独，坚决支持维护国家领土主权**