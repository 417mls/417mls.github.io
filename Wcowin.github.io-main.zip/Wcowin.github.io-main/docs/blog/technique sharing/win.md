---
tags:
  - 技术分享
  - win
---
:simple-windows:镜像下载、壁纸、KMS激活  
我的夸克网盘链接：<https://pan.quark.cn/s/fad94361d9a5> 提取码：XLvV  

[Win11镜像网站](https://latest10.win/)

[Office2010-2021下载](https://tvs3g25cto.feishu.cn/drive/folder/fldcnFpXs7qXIOFfHH2sSps9tdK)
***
**windows KMS激活：**   
你只需要使用管理员权限运行cmd执行一句命令就足够：  
```
slmgr /skms kms.03k.org
```

***
**一句命令激活OFFICE**  
首先你的OFFICE必须是VOL版本，否则无法激活。 

找到你的office安装目录，比如C:\Program Files (x86)\Microsoft Office\Office16  

64位的就是C:\Program Files\Microsoft Office\Office16  

office16是office2016，office15就是2013，office14就是2010.  

然后目录对的话，该目录下面应该有个OSPP.VBS。  

!!! note
    详见：[本站上线KMS服务~一句命令激活windows/office](https://03k.org/kms.html)