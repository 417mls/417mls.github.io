<center> <font face="宋体" color= #4b78d8 size=6 >
All knowledge is, in final analysis, history.  
All sciences are, in the abstract, mathematics.  
All judgements are, in their，rationale, statistics.  
在终极的分析中,一切知识都是历史；  
在抽象的意义下,一切科学都是数学；  
在理性的基础上,所有的判断都是统计学。  
——C.R.Rao《统计与真理》
</font>
</center>