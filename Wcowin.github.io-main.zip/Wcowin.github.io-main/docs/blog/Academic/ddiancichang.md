---
title: 电磁场与电磁波常用符号公式整理（手写）
---
![WechatIMG706.jpg](https://s2.loli.net/2024/02/01/pPXLIG5T8brVwex.jpg)
![WechatIMG707.jpg](https://s2.loli.net/2024/02/01/FLzhA3Wxgmdi6jy.jpg)
![WechatIMG708.jpg](https://s2.loli.net/2024/02/01/jDIw3F1CfUoNZl2.jpg)