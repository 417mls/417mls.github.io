---
title: iphone多账号如何不频繁登录，双重认证
tags:
  - iphone
---
如果你的iPhone每次切换App store需要双重验证或者想不切换ID就更新不同地区App而不需要再次密码验证，那么你可以在  

**设置-邮件-账户**里把外区ID添加进去    
![img](https://cn.mcecy.com/image/20230321/d1d6b755de2b12deaed1b408c7347cb3.jpeg)
那么以后你再切换商店就不需要验证，App更新也不需要验证外区密码。