---
title: 苹果iphone /iOS 限免网站合集
tags:
  - iphone
---

mergeek

<https://mergeek.com/free/apps>

一个安卓、苹果app推介网站，其中ios限免与优惠更新比较及时。还支持微信服务号订阅  
![](https://pic.appmiu.com/gh/abcmiao/img@main/pic/20210604105805.png)



iOSnoops

<https://www.iosnoops.com/>

iOSnoops 每天都会免费提供iOS应用的汇总。这个没有应用程式版本，但您可以在他们的行动网站上查看交易，然后点击进入App Store。您还可以查看前几天的交易。如果交易仍在进行中，您会在状态一词旁边看到一个绿色图标。过期后，该图标将显示为红色。iOSnoops还具有销售的实时更新，免费的应用程序和新版本，因此您不必等待每日汇总。  
![](https://pic.appmiu.com/gh/abcmiao/img@main/pic/20210604135131.png)



appsliced

<https://appsliced.co/>

App Sliced是免费的替代App Store体验。发现最好的应用程序，同时节省资金！

![](https://pic.appmiu.com/gh/abcmiao/img@main/pic/20210604135635.png)

appticker

<https://www.appticker.com/>

提供历史价格信息以及每天最新优惠线面活动，更新速度尚可，可以作为获取限免价格备用获取渠道源。

![](https://pic.appmiu.com/gh/abcmiao/img@main/pic/20210604135002.png)

gofans

<https://gofans.cn/>

一个每日推送最新ios限免及优惠app的网站，更新比较迅速。

![](https://pic.appmiu.com/gh/abcmiao/img@main/pic/20210604134818.png)

appwall

<https://appwall.today/>

一个每日推送最新ios限免及优惠app的网站，更新比较迅速。

反斗限免

<http://free.apprcn.com/>

反斗限免是一个每日推送全平台限免网站，其中Windows软件更新比较迅速。

备用渠道

<https://appagg.com/>

温馨提示

1，可以用rss订阅器，如inoreader订阅上述[网站](https://www.appmiu.com/tag/网站)的订阅源，每天可以第一时间收到消息，不用再去网站上找了

2，以上网址并不是所有都可以直接打开，部分站点可能需要[魔法上网工具](../technique%20sharing/kexue.md)
