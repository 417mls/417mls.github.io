---
title: 苹果手机去除开屏广告
tags:
  - iphone
---
法一：  

操作步骤

1.打开设置

2.找到「屏幕使用时间」并打开

3.找到「内容和隐私访问限制」并打开

4.下滑找到「广告」设置为不允许

完成上面的步骤绝大部分我们常用软件的开屏广告就已经去除了。
***

法二：  

<https://github.com/wubuzhi/AdBlockByIOS>{target=“_blank”}

***

顺便一提**安卓手机**去除开屏AD的方法：<https://wwe.lanzouw.com/b01v0g3wj>{target=“_blank”}  密码：1233  
下载李跳跳即可