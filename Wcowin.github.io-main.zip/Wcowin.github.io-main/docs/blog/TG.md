---
tags:
  - Telegram
---
[:simple-telegram:](https://web.telegram.org/z/)

 <p>更新时间:2023-3-24<br />
原文出处:<a href="https://congcong0806.github.io/2018/04/24/Telegram">Telegram 群组、频道、机器人 - 汇总分享</a></p>

<ul>
  <li>Telegram 私聊:<a href="https://t.me/congcongx_bot">https://t.me/congcongx_bot</a></li>
  <li>Telegram 社群:<a href="https://t.me/tgcnx">https://t.me/tgcnx</a></li>
  <li>Telegram 频道:<a href="https://t.me/tgcnz">https://t.me/tgcnz</a></li>  



因为阿里域名警告，有关TG的文章，梯子的问题，暂时不更新，等待解决中。。。