![](https://wenanb.com/wp-content/uploads/2022/10/2022102201542164.jpg)

<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=865632948&auto=0&height=66"></iframe>

落叶无归根 单丝不成线  

无所寄托 亦无心流浪  

你把红豆赠我不如写我一首歌  

落款你的名字 工整又好看  

若把你比作歌  

你便是那高山流水  

佳人伴舞 天地伴舞  

绝弦的美  

若把你比作歌  

歌写的我缠绵悱恻  

恒顺众生 迁走我魂  

绝弦的美  

落叶无归根 单丝不成线  

有嘴无心 亦有才无命  

不一起看星星 星星它亮有什么用  

你我矢志不渝 举案又齐眉  

若把你比作歌  

你便是那高山流水  

佳人伴舞 天地伴舞  

绝弦的美  

若把你比作歌  

歌写的我缠绵悱恻  

恒顺众生 迁走我魂  

绝弦的美  

恒顺众生 迁走我魂  

绝弦的美  