![]()
<!-- <iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=1979258149&auto=1&height=66"></iframe> -->
<iframe allow="autoplay *; encrypted-media *;" frameborder="0" height="150" style="width:100%;max-width:660px;overflow:hidden;background:transparent;" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-storage-access-by-user-activation allow-top-navigation-by-user-activation" src="https://embed.music.apple.com/cn/album/%E7%B5%B6%E9%A0%82%E8%AE%83%E6%AD%8C/1641396253?i=1641396255"></iframe>
ほとばしく香る君のその髪が  
僕の心を踊らせたんです  
靡くだけ　今は　それだけで  
この身　屈めますから  

Midnight光線Darling  
堪えきれぬ欲望に任せて  
Midnight光線Darling  
僕に仕える気になったら  

願うは三度の絶頂を  
胸の中で至る  
今宵も僕らは繁栄の  
ために愛を放つ  

抗いの呟きとは裏腹に  
身体は嬉しそうに動いたんです  
この翼に輪を付けるかは  
僕ら次第ですから  
真面目ですかな  
淫らですかな  

Midnight光線Darling  
愛と欲に純白を求めて  
Midnight光線Darling  
僕を拒む気になっても  

願うは三度の絶頂を  
胸の中で至る  
零れる涙が飽和して  
僕は今に果てる  

その溢れた吐息の原因なんだって？  
いったいどこからいったって？  
ドキドキなんだって？  
よろめく恐怖が原因なんだって？  
それでも君ならいいんだって  
さらに  

願うは三度の絶頂を  
胸の中で至る  
今宵も僕らは繁栄の  
ために愛をもっと費やしてよ  

願うは三度の絶頂を  
胸の中で至る  
零れる涙が飽和して  
僕は今に果てる