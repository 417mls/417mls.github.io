<script type="text/javascript">   
loopy()   
function loopy() {   
var sWord =""  
while (sWord != "1221") {//设置密码
sWord = prompt("输入正确密码才能访问")   
}   
alert("欢迎小王♡+♡=♡²")   
}   
</script> 

<script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS_HTML" async></script>

<div align=center> 
         <img src="https://readme-typing-svg.herokuapp.com?color=%2336BCF7&size=30&center=true&vCenter=true&width=600&height=50&lines= 富士山从海拔3360米开始;所属权便属于浅间神社;但富士山下海拔1.75米的我;所属权+可以属于你" alt="Headline;" /> 
     </div> 

<font face="宋体" size=6 >L=</font>
 $\displaystyle\frac{5}{2}\sum_{n=1}^\infty \frac{1+\frac{1}{2}+···\frac{1}{n+1}}{n(n+1)}$  
<font face="宋体" size=6 >O=</font>
$\displaystyle\underset{x,y,z,\omega>0}{\underbrace{max}}(\frac{xy+2yz+3zw}{5x^2+6y^2+9z^2+9\omega^2})^2$    
<font face="宋体" size=6 >V=</font>
$\displaystyle\displaystyle\int_{0}^{+\infty}\frac{e^{-\frac{4}{\pi}x^2}-e^{-\frac{225}{\pi}{x^2}}}{x^2}dx$  
<font face="宋体" size=6 >E=</font>
$\displaystyle7\lim_{n \rightarrow\infty}\frac{n+\sqrt{n}+···\sqrt[n]{n}}{n}$




<!-- <a href="https://music.apple.com/cn/album/%E3%81%99%E3%81%9A%E3%82%81/1656709799?i=1656709800" target="_blank">
  <img class="img1" src="https://cn.mcecy.com/image/20230530/a955c522e7b6cacb86dd7aa650fd1a0a.png" alt="">
</a> -->

小王请关灯（点击:octicons-moon-16:）

<!-- ![Image title](https://cn.mcecy.com/image/20230530/a955c522e7b6cacb86dd7aa650fd1a0a.png#only-light) -->

![Image title](https://s2.loli.net/2024/02/01/o9YHsqfG7NjwMiT.jpg#only-light)
![Image title](https://img95.699pic.com/element/40123/2996.png_300.png#only-dark)